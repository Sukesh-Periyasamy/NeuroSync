import serial
import time

PORT = "COM13"
BAUD = 115200

ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)

print("Connected to Arduino on COM13...")
print("Waiting for calibration...")
print("------------------------------")
print("Watch env= values:")
print("  Still finger  → env= ?")
print("  Light press   → env= ?")
print("  Normal press  → env= ?")
print("  Hard press    → env= ?")
print("------------------------------")

try:
    while True:
        line = ser.readline().decode("utf-8", errors="ignore").strip()
        if not line:
            continue
        print(line)

except KeyboardInterrupt:
    print("\nStopped!")

ser.close()