// ─────────────────────────────────────
// EMG Football Controller — Final Code
// Left hand  → A0
// Right hand → A1
// Kick (leg) → A2
// ─────────────────────────────────────

const int LEFT_PIN  = A0;
const int RIGHT_PIN = A1;
const int KICK_PIN  = A2;

// ── Thresholds (calibrated from your body data) ──
const int ACT_L         = 40;
const int ACT_R         = 45;
const int MIN_PEAK_L    = 60;
const int MIN_PEAK_R    = 55;
const int KICK_THRESH   = 20;
const int MIN_KICK_PEAK = 30;

// ── Timing ──
const int DEBOUNCE_MS   = 350;
const int GESTURE_DELAY = 150;
const int REST_CONFIRM  = 250;
const int KICK_DEBOUNCE = 600;

// ── Hand signal variables ──
float smoothL = 0, smoothR = 0;
float envL    = 0, envR    = 0;
float prevEnvL = 0, prevEnvR = 0;
int   baseL   = 0, baseR   = 0;

// ── Kick signal variables ──
float smoothK  = 0;
float envK     = 0;
float prevEnvK = 0;
int   baseK    = 0;

// ── Forward state ──
bool forwardActive    = false;
bool restTimerStarted = false;
unsigned long restSince = 0;

// ── Left/Right state ──
bool leftTriggered  = false;
bool rightTriggered = false;
bool leftPending    = false;
bool rightPending   = false;
unsigned long leftSince  = 0;
unsigned long rightSince = 0;
float peakL = 0, peakR = 0;

// ── Kick state ──
bool kickPending   = false;
bool kickTriggered = false;
float peakK        = 0;
unsigned long kickSince    = 0;
unsigned long lastKickTime = 0;

// ── Output ──
String lastAction = "REST";
unsigned long lastPrint = 0;

// ─────────────────────────────────────
// Filters
// ─────────────────────────────────────
float smoothFilter(float previous, int newVal) {
  return previous * 0.8 + newVal * 0.2;
}

int rectify(float signal, int baseline) {
  int val = abs((int)signal - baseline);
  if (val < 5) val = 0;
  return val;
}

float envelopeFilter(int rectified, float envelope) {
  if (rectified > envelope) return rectified;
  return envelope * 0.85;
}

float kickEnvelope(int rectified, float envelope) {
  if (rectified > envelope) return rectified;
  return envelope * 0.85;
}

// ─────────────────────────────────────
// Setup
// ─────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("=== EMG Football Controller ===");
  Serial.println("Relax ALL muscles... calibrating 3 seconds");
  delay(3000);

  // Calibrate all 3 channels
  long sumL = 0, sumR = 0, sumK = 0;
  for (int i = 0; i < 300; i++) {
    sumL += analogRead(LEFT_PIN);
    sumR += analogRead(RIGHT_PIN);
    sumK += analogRead(KICK_PIN);
    delay(10);
  }

  baseL = sumL / 300;
  baseR = sumR / 300;
  baseK = sumK / 300;

  smoothL = baseL;
  smoothR = baseR;
  smoothK = baseK;

  Serial.print("Left  baseline="); Serial.println(baseL);
  Serial.print("Right baseline="); Serial.println(baseR);
  Serial.print("Kick  baseline="); Serial.println(baseK);
  Serial.println("Ready! Flex now...");
  Serial.println("------------------------------");
}

// ─────────────────────────────────────
// Main Loop
// ─────────────────────────────────────
void loop() {
  unsigned long now = millis();

  // ── Read and process all 3 channels ──
  prevEnvL = envL;
  prevEnvR = envR;
  prevEnvK = envK;

  smoothL = smoothFilter(smoothL, analogRead(LEFT_PIN));
  smoothR = smoothFilter(smoothR, analogRead(RIGHT_PIN));
  smoothK = smoothFilter(smoothK, analogRead(KICK_PIN));

  int rectL = rectify(smoothL, baseL);
  int rectR = rectify(smoothR, baseR);
  int rectK = abs((int)smoothK - baseK);
  if (rectK < 3) rectK = 0;

  envL = envelopeFilter(rectL, envL);
  envR = envelopeFilter(rectR, envR);
  envK = kickEnvelope(rectK, envK);

  // ── Reset triggered flags when signal drops ──
  if (envL < ACT_L) {
    leftTriggered = false;
    peakL = 0;
  }
  if (envR < ACT_R) {
    rightTriggered = false;
    peakR = 0;
  }
  if (envK < KICK_THRESH) {
    kickTriggered = false;
    peakK = 0;
    kickPending = false;
  }

  // ── Track peaks ──
  if (envL > peakL) peakL = envL;
  if (envR > peakR) peakR = envR;
  if (envK > peakK) peakK = envK;

  // ── FORWARD entry ──
  if (envL > ACT_L && envR > ACT_R) {
    if (!forwardActive) {
      forwardActive    = true;
      restTimerStarted = false;
      leftPending      = false;
      rightPending     = false;
      leftTriggered    = true;
      rightTriggered   = true;
      peakL = 0;
      peakR = 0;
    }
  }

  // ── FORWARD exit with rest confirmation ──
  if (forwardActive && envL < ACT_L && envR < ACT_R) {
    if (!restTimerStarted) {
      restSince        = now;
      restTimerStarted = true;
    }
    if (now - restSince > REST_CONFIRM) {
      forwardActive    = false;
      restTimerStarted = false;
      lastAction       = "REST";
    }
  }

  // Cancel rest timer if hands come back
  if (forwardActive && restTimerStarted && (envL > ACT_L || envR > ACT_R)) {
    restTimerStarted = false;
  }

  // ── LEFT pending — rising signal only ──
  if (!forwardActive && !leftTriggered &&
      envL > ACT_L && envR < ACT_R &&
      envL > prevEnvL) {
    if (!leftPending) {
      leftPending = true;
      leftSince   = now;
      peakL       = 0;
    }
  } else if (envL < ACT_L) {
    leftPending = false;
  }

  // ── RIGHT pending — rising signal only ──
  if (!forwardActive && !rightTriggered &&
      envR > ACT_R && envL < ACT_L &&
      envR > prevEnvR) {
    if (!rightPending) {
      rightPending = true;
      rightSince   = now;
      peakR        = 0;
    }
  } else if (envR < ACT_R) {
    rightPending = false;
  }

  // ── KICK pending — rising signal only ──
  if (!kickTriggered && envK > KICK_THRESH && envK >= prevEnvK) {
    if (!kickPending) {
      kickPending = true;
      kickSince   = now;
      peakK       = 0;
    }
  }

  // ─────────────────────────────────────
  // Gesture Decision
  // ─────────────────────────────────────
  String action = "REST";

  // KICK — highest priority
  if (kickPending &&
      peakK > MIN_KICK_PEAK &&
      (now - lastKickTime) > KICK_DEBOUNCE) {
    action        = "KICK";
    kickTriggered = true;
    kickPending   = false;
    lastKickTime  = now;
    peakK         = 0;
  }
  // FORWARD
  else if (forwardActive) {
    action = "FORWARD";
  }
  // LEFT — must reach minimum peak
  else if (leftPending &&
           (now - leftSince) > GESTURE_DELAY &&
           peakL > MIN_PEAK_L) {
    action        = "LEFT";
    leftTriggered = true;
    leftPending   = false;
  }
  // RIGHT — must reach minimum peak
  else if (rightPending &&
           (now - rightSince) > GESTURE_DELAY &&
           peakR > MIN_PEAK_R) {
    action         = "RIGHT";
    rightTriggered = true;
    rightPending   = false;
  }

  // ── Print only on change ──
  if (action != lastAction && (now - lastPrint) > DEBOUNCE_MS) {
    if (action != "REST") {
      Serial.println(action);
    }
    lastAction = action;
    lastPrint  = now;
  }

  delay(30);
}