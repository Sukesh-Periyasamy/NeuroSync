const int LEFT_PIN = A0;

float smoothL = 0;
int   baseL   = 0;

float smoothFilter(float previous, int newVal) {
  return previous * 0.8 + newVal * 0.2;
}

void setup() {
  Serial.begin(115200);
  Serial.println("Relax LEFT hand... calibrating 3 seconds");
  delay(3000);

  long sumL = 0;
  for (int i = 0; i < 300; i++) {
    sumL += analogRead(LEFT_PIN);
    delay(10);
  }

  baseL = sumL / 300;
  smoothL = baseL;

  Serial.print("Left baseline="); Serial.println(baseL);
  Serial.println("Calibration done!");
  delay(1000);

  // CSV header
  Serial.println("time_ms,raw,env");
}

void loop() {
  smoothL = smoothFilter(smoothL, analogRead(LEFT_PIN));

  int env = abs((int)smoothL - baseL);
  if (env < 5) env = 0;

  Serial.print(millis());
  Serial.print(",");
  Serial.print((int)smoothL);
  Serial.print(",");
  Serial.println(env);

  delay(20);
}